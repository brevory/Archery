const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const connectionSchema = new Schema({
        title: {type: String, required: [true, 'title is required']},
        catName: {type: String, required: [true, 'category is required']},
        details: {type: String, required: [true, 'details are required']},
        date: {type: String, required: [true, 'date is required']},
        start: {type: String, required: [true, 'start time is required']},
        end: {type: String, required: [true, 'end time is required']},
        author: {type: Schema.Types.ObjectId, ref: 'User'},
        host: {type: String, required: [true, 'host is required']}
},
{timestamps: true}
);

module.exports = mongoose.model('Connection', connectionSchema);